CREATE PROCEDURE sp_createUser(IN p_username VARCHAR(45), IN p_password VARCHAR(45))
  BEGIN
    if ( select exists (select Username from users where Username = p_username) ) THEN
     
        select 'Username Exists !!';
     
    ELSE
     
        insert into users
        (
            Username,
            Password
        )
        values
        (
            p_username,
            p_password
        );
     
    END IF;
END;
